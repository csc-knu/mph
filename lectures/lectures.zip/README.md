<!--DEBUG-->

_Якщо захочете правити вихідний код лекцій, то вам знадобляться [univ.sty](univ.sty) і [th.sty](th.sty)._
_Зараз опрацьовані лекції №№1&ndash;20._

### Перший розділ

_Станом на 5 червня 2019 р. цей розділ повністю відредагований Анатолієм Володимировичем._

[разом](ch-1/ch-1.pdf)

1. Лекція №1: [pdf](ch-1/1.pdf), [docx](ch-1/1.docx), [LaTeX source](ch-1/1.tex)

2. Лекція №2: [pdf](ch-1/2.pdf), [docx](ch-1/2.docx), [LaTeX source](ch-1/2.tex)

3. Лекція №3: [pdf](ch-1/3.pdf), [docx](ch-1/3.docx), [LaTeX source](ch-1/3.tex)

4. Лекція №4: [pdf](ch-1/4.pdf), [docx](ch-1/4.docx), [LaTeX source](ch-1/4.tex)

5. Лекція №5: [pdf](ch-1/5.pdf), [docx](ch-1/5.docx), [LaTeX source](ch-1/5.tex)

6. Лекція №6: [pdf](ch-1/6.pdf), [docx](ch-1/6.docx), [LaTeX source](ch-1/6.tex)

### Другий розділ

[разом](ch-2/ch-2.pdf)

7. Лекція №7: [pdf](ch-2/7.pdf), [docx](ch-2/7.docx), [LaTeX source](ch-2/7.tex)

8. Лекція №8: [pdf](ch-2/8.pdf), [docx](ch-2/8.docx), [LaTeX source](ch-2/8.tex)

9. Лекція №9: [pdf](ch-2/9.pdf), [docx](ch-2/9.docx), [LaTeX source](ch-2/9.tex)

10. Лекція №10: [pdf](ch-2/10.pdf), [docx](ch-2/10.docx), [LaTeX source](ch-2/10.tex)

11. Лекція №11: [pdf](ch-2/11.pdf), [docx](ch-2/11.docx), [LaTeX source](ch-2/11.tex)

12. Лекція №12: [pdf](ch-2/12.pdf), [docx](ch-2/12.docx), [LaTeX source](ch-2/12.tex)

13. Лекція №13: [pdf](ch-2/13.pdf), [docx](ch-2/13.docx), [LaTeX source](ch-2/13.tex)

14. Лекція №14: [pdf](ch-2/14.pdf), [docx](ch-2/14.docx), [LaTeX source](ch-2/14.tex)

    _Станом на 16 червня 2019 р. цей розділ відредагований Анатолієм Володимировичем до цього місця._

15. Лекція №15: [pdf](ch-2/15.pdf), [docx](ch-2/15.docx), [LaTeX source](ch-2/15.tex)

16. Лекція №16: [pdf](ch-2/16.pdf), [docx](ch-2/16.docx), [LaTeX source](ch-2/16.tex)

### Третій розділ

[лекції 17&ndash;20](ch-3/ch-3.pdf)

17. Лекція №17: [pdf](ch-3/17.pdf), [docx](ch-3/17.docx), [LaTeX source](ch-3/17.tex)

18. Лекція №18: [pdf](ch-3/18.pdf), [docx](ch-3/18.docx), [LaTeX source](ch-3/18.tex)

19. Лекція №19: [pdf](ch-3/19.pdf), [docx](ch-3/19.docx), [LaTeX source](ch-3/19.tex)

20. Лекція №20: [pdf](ch-3/20.pdf), [docx](ch-3/20.docx), [LaTeX source](ch-3/20.tex)

21. Лекція №21: [pdf](ch-3/21.pdf), [docx](ch-3/21.docx), [LaTeX source](ch-3/21.tex)

22. Лекція №22: [pdf](ch-3/22.pdf), [docx](ch-3/22.docx)

23. Лекція №23: [pdf](ch-3/23.pdf), [docx](ch-3/23.docx)

24. Лекція №24: [pdf](ch-3/24.pdf), [docx](ch-3/24.docx)

25. Лекція №25: [pdf](ch-3/25.pdf), [docx](ch-3/25.docx)

26. Лекція №26: [pdf](ch-3/26.pdf), [docx](ch-3/26.docx)

27. Лекція №27: [pdf](ch-3/27.pdf), [docx](ch-3/27.docx)

### Четвертий розділ

28. Лекція №28: [pdf](ch-4/28.pdf), [docx](ch-4/28.docx)

29. Лекція №29: [pdf](ch-4/29.pdf), [docx](ch-4/29.docx)

30. Лекція №30: [pdf](ch-4/30.pdf), [docx](ch-4/30.docx)

31. Лекція №31: [pdf](ch-4/31.pdf), [docx](ch-4/31.docx)

32. Лекція №32: [pdf](ch-4/32.pdf), [docx](ch-4/32.docx)

33. Лекція №33: [pdf](ch-4/33.pdf), [docx](ch-4/33.docx)

---

[Назад на головну](../README.md)
